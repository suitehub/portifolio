// firestore.js
// Acesso ao Firestore — Turma XI | Teologia SALT-FAP

import {
  collection,
  getDocs,
  query,
  where,
  orderBy,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

import { db } from "./firebase.js";

console.log("firestore.js carregou");

// ===== ANÚNCIOS =====

export async function listarAnuncios() {
  const q = query(
    collection(db, "anuncios"),
    where("ativo", "==", true),
    orderBy("criadoEm", "desc")
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}

export async function criarAnuncio(dados) {
  return addDoc(collection(db, "anuncios"), {
    ...dados,
    ativo: true,
    criadoEm: serverTimestamp()
  });
}

export async function ocultarAnuncio(id) {
  const ref = doc(db, "anuncios", id);
  return updateDoc(ref, { ativo: false });
}


/* =======================
   DISCIPLINAS
======================= */

export async function listarDisciplinas() {
  const q = query(
    collection(db, "disciplinas"),
    where("ativo", "==", true),
    orderBy("nome")
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}

/* =======================
   AVALIAÇÕES
======================= */

export async function listarAvaliacoesPorDisciplina(disciplinaId) {
  const q = query(
    collection(db, "avaliacoes"),
    where("ativo", "==", true),
    where("disciplinaId", "==", disciplinaId),
    orderBy("data")
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}

export async function criarDisciplina(nome) {
  return await addDoc(collection(db, "disciplinas"), {
    nome: nome,
    ativo: true,
    criadoEm: serverTimestamp()
  });
}

export async function editarDisciplina(id, novoNome) {
  const ref = doc(db, "disciplinas", id);
  return updateDoc(ref, {
    nome: novoNome
  });
}

export async function ocultarDisciplina(id) {
  const ref = doc(db, "disciplinas", id);
  return updateDoc(ref, {
    ativo: false
  });
}

// =======================
// AVALIAÇÕES - ADMIN
// =======================

export async function criarAvaliacao(dados) {
  return addDoc(collection(db, "avaliacoes"), {
    ...dados,
    ativo: true,
    criadoEm: serverTimestamp()
  });
}

export async function editarAvaliacao(id, dados) {
  const ref = doc(db, "avaliacoes", id);
  return updateDoc(ref, dados);
}

export async function ocultarAvaliacao(id) {
  const ref = doc(db, "avaliacoes", id);
  return updateDoc(ref, {
    ativo: false
  });
}

// =======================
// AVALIAÇÕES (HOME)
// =======================

export async function listarAvaliacoesAtivas() {
  // 1. Buscar disciplinas
  const disciplinasSnap = await getDocs(
    query(
      collection(db, "disciplinas"),
      where("ativo", "==", true)
    )
  );

  const disciplinasMap = {};
  disciplinasSnap.forEach(doc => {
    disciplinasMap[doc.id] = doc.data().nome;
  });

  // 2. Buscar avaliações
  const avaliacoesSnap = await getDocs(
    query(
      collection(db, "avaliacoes"),
      where("ativo", "==", true),
      orderBy("data", "asc")
    )
  );

  // 3. Montar avaliações com nome da disciplina
  return avaliacoesSnap.docs.map(doc => {
    const data = doc.data();

    return {
      id: doc.id,
      ...data,
      disciplinaNome: disciplinasMap[data.disciplinaId] || "—"
    };
  });
}

// =======================
// EVENTOS CALENDÁRIO
// =======================

export async function listarEventos() {
  const q = query(
    collection(db, "eventos"),
    where("ativo", "==", true)
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}

export async function criarEvento(dados) {
  return addDoc(collection(db, "eventos"), {
    ...dados,
    ativo: true,
    criadoEm: serverTimestamp()
  });
}


// =======================
// EVENTOS
// =======================

export async function editarEvento(id, dados) {
  const ref = doc(db, "eventos", id);
  return updateDoc(ref, dados);
}

export async function ocultarEvento(id) {
  const ref = doc(db, "eventos", id);
  return updateDoc(ref, {
    ativo: false
  });
}

// =======================
// DÚVIDAS — CRIAR
// =======================

export async function criarDuvida(dados) {

  return addDoc(collection(db, "duvidas"), {
    pergunta: dados.pergunta,
    nome: dados.nome || "",
    disciplina: dados.disciplina || "",
    resposta: "",
    status: "pendente",
    publica: false,
    criadoEm: serverTimestamp(),
    respondidoEm: null
  });

}


// =======================
// DÚVIDAS — MURAL
// =======================

export async function listarDuvidasPublicas() {

  const q = query(
    collection(db, "duvidas"),
    where("status", "==", "respondida"),
    where("publica", "==", true),
    orderBy("respondidaEm", "desc")
  );

  const snap = await getDocs(q);

  return snap.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}

// =======================
// DÚVIDAS — LIDERANÇA
// =======================

export async function listarDuvidasPendentes() {

  const q = query(
    collection(db, "duvidas"),
    where("status", "==", "pendente"),
    orderBy("criadoEm", "asc")
  );

  const snap = await getDocs(q);

  return snap.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}

export async function responderDuvida(id, resposta) {

  const ref = doc(db, "duvidas", id);

  return updateDoc(ref, {
    resposta,
    status: "respondida",
    publica: true,
    respondidaEm: serverTimestamp()
  });
}

// =======================
// 📚 MEDITAÇÃO — SEMANA
// =======================

export async function salvarMeditacaoSemana(dados) {

  return addDoc(collection(db, "meditacoes"), {
    ...dados,
    criadoEm: serverTimestamp()
  });

}

export async function listarMeditacoesSemana() {

  const snapshot = await getDocs(
    query(
      collection(db, "meditacoes"),
      orderBy("data", "asc")
    )
  );

  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}

// =======================
// MEDITAÇÕES
// =======================

export async function criarMeditacao(dados) {
  return addDoc(collection(db, "meditacoes"), {
    nome: dados.nome || "",
    data: dados.data, // string yyyy-mm-dd
    criadoEm: serverTimestamp()
  });
}

export async function editarMeditacao(id, dados) {
  const ref = doc(db, "meditacoes", id);
  return updateDoc(ref, {
    nome: dados.nome || "",
    data: dados.data
  });
}

export async function excluirMeditacao(id) {
  const ref = doc(db, "meditacoes", id);
  return deleteDoc(ref);
}

export async function listarMeditacoes() {
  const snap = await getDocs(
    query(collection(db, "meditacoes"), orderBy("data", "asc"))
  );

  return snap.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
}
